//
//  AppDelegate.h
//  Funn
//
//  Created by Hanyu Liu on 3/14/19.
//  Copyright © 2019 Hanyu Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

